<div id="footer">
    <p>Copyright SullyScapes <span id="date"></span></p>
</div>
<script type="text/javascript" src="https://sullyscapes.com/blog/wp-content/themes/SullyScapesTheme/interactivity.js"></script>
<div>
    <?php wp_footer(); ?>
</div>


</body>
</html>