if(window.location.pathname.includes("/page/")){
    window.scrollTo(0, 1500);
}